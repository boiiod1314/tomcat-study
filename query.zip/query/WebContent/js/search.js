function Page(){
  this.keyword = this.$("keyword");
  this.search = this.$("search");
  this.form = this.$("myform");
}

Page.prototype.$=function(id){
  return document.getElementById(id);
};

Page.prototype.handleEvent=function(){
  var This = this;
  This.keyword.focus();
  This.keyEnter();
  This.search.onclick=function(){
    This.submit();
  };
};
Page.prototype.keyEnter=function(){
  var This = this;
  document.onkeypress=function(event){
    var evt = window.event || event; 
    var code = evt.keyCode || evt.charCode;
    if(code==13){
      This.submit();
    }
  }
};

Page.prototype.submit=function(){
  var keyword = this.keyword.value;
  //alert(keyword);
  this.form.submit();
};

Page.prototype.init=function(){
  this.handleEvent();
};

window.onload=function(){

  new Page().init();

}